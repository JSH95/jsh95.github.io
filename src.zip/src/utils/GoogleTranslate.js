// // src/components/GoogleTranslate.jsx
// import { useEffect } from "react";
//
// const GoogleTranslate = () => {
//     useEffect(() => {
//         const script = document.createElement("script");
//         script.src = "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
//         script.async = true;
//         document.body.appendChild(script);
//     }, []);
//
//     return <div id="google_translate_element" style={{ float: "right", margin: "10px" }} />;
// };
//
// export default GoogleTranslate;
