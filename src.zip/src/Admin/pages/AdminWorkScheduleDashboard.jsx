import React, { useEffect, useState } from "react";
import {BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, Cell} from "recharts";
import "../../config/index.css";
import {useNavigate} from "react-router-dom";
import {useAuth} from "../../config/AuthContext";
import useWorkHours from "../../jobScedule/utils/useWorkHours";
import {useLoading} from "../../utils/LoadingContext";

const AdminWorkScheduleDashboard = () => {
    const { setIsProcessing } = useLoading();
    const { role } = useAuth();
    const navigate = useNavigate();
    const [chartData, setChartData] = useState([]);
    const today = new Date();
    const [year, setYear] = useState(today.getFullYear());
    const [month, setMonth] = useState(today.getMonth() + 1);
    const { data, loadingWorkHours, errorWorkHours } = useWorkHours(year, month, null, role);

    useEffect(() => {
        if (!loadingWorkHours && data.length > 0) {
            setChartData(data); // 데이터가 있을 때만 사용
        }
    } , [data, loadingWorkHours]);

    const changeMonth = (direction) => {
        setMonth((prev) => {
            let newMonth = prev + direction;
            let newYear = year;

            if (newMonth < 1) {
                newYear -= 1;
                newMonth = 12;
            } else if (newMonth > 12) {
                newYear += 1;
                newMonth = 1;
            }

            setYear(newYear);
            return newMonth;
        });
    };


    function moveToDetail(id){
        window.alert("상세 페이지로 이동합니다 : " + id + " "+ year + "년" +  " " + month + "월");
        navigate(`/workSchedule/adminList/${id}`, { state: { year, month }});
    }

    return (
        <div className="container">
            <div className="d-flex justify-content-between align-items-center mb-3">
                <button className="btn btn-secondary" onClick={() => changeMonth(-1)}>이전 달</button>
                <h3>{year}년 {month}월</h3>
                <button className="btn btn-secondary" onClick={() => changeMonth(1)}>다음 달</button>
            </div>
            <div className="table-responsive">
                <table className="table table-hover"
                style={{ tableLayout: 'fixed', width: '100%' }}>
                    <thead>
                    <tr>
                        <th className="table-header" style={{ minWidth: '150px', whiteSpace: 'nowrap' }}>승인 단계</th>
                        <th className="table-header" style={{ minWidth: '150px', whiteSpace: 'nowrap' }}>이름</th>
                        <th className="table-header" style={{ minWidth: '150px', whiteSpace: 'nowrap' }}>기본 근무시간(+40 시간)</th>
                        <th className="table-header" style={{ minWidth: '150px', whiteSpace: 'nowrap' }}>총 근무시간</th>
                        <th className="table-header" style={{ minWidth: '150px', whiteSpace: 'nowrap' }}>초과 근무시간</th>
                        <th className="table-header table-header-fixed"  style={{ minWidth: '200px', whiteSpace: 'nowrap' }}>
                            <div className="x-axis-ticks">
                                {/* X축 눈금 값을 표시합니다. */}
                                {[0, 50, 100, 150, 200].map((tick) => (
                                    <span key={tick} className="x-axis-tick">
                                    {tick}
                                    </span>
                                ))}
                            </div>
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    {!errorWorkHours ? chartData
                        .sort((a, b) => a.employeeName.localeCompare(b.employeeName))
                        .map((entry) => (
                        <tr key={entry.employeeName}
                            className="hover:bg-blue-50 cursor-pointer transition"
                            onClick={() => moveToDetail(entry.employeeId)}
                            style={{
                                cursor: "pointer",
                                transition: "color 0.2s ease-in-out",
                            }}
                        >
                            <td className="table-data"> {entry.status}</td>
                            <td className="table-data" >{entry.employeeName}</td>
                            <td className="table-data"> {Number(entry.basicWorkHours) + 40}</td>
                            <td className="table-data"> {entry.totalWorkHours}</td>
                            <td className="table-data"> {entry.totalWorkHours - (entry.basicWorkHours + 40) > 0 ? (entry.totalWorkHours - (entry.basicWorkHours + 40)).toFixed(1) : "없음"}</td>
                            <td className="chart-cell">
                                <ResponsiveContainer width="100%" height={30}>
                                    <BarChart
                                        data={[entry]} // 각 행의 데이터를 배열로 전달
                                        layout="vertical"
                                        margin={{ top: 0, right: 0, left:0, bottom: 0 }}
                                    >
                                        <XAxis
                                            type="number"
                                            domain={[0, 250]}
                                            tickCount={7}
                                            hide={true}
                                        />
                                        <YAxis
                                            dataKey="username"
                                            type="category"
                                            hide={true}
                                        />
                                        <Bar dataKey="totalWorkHours">
                                            <Cell fill={entry.totalWorkHours >=
                                            (Number(entry.basicWorkHours) + 40) ? "#0065ff"
                                                : entry.totalWorkHours >= Number(entry.basicWorkHours) ? "#61e368"
                                                    : "#c20000"
                                            }
                                            />
                                        </Bar>
                                    </BarChart>
                                </ResponsiveContainer>
                            </td>
                        </tr>
                    ))
                        : "오류"
                    }
                    </tbody>
                </table>
            </div>

            <div className="mb-2 mt-4">
                <h2>이번 달 직원별 근무 요약(테스트 중)</h2>
                <table border="1" cellPadding="8">
                    <thead>
                    <tr>
                        <th>사원명</th>
                        <th>出社日数</th>
                        <th>実作業時間</th>
                        <th>遅刻</th>
                        <th>夜勤(時間)</th>
                        <th>欠勤</th>
                        <th>代休</th>
                        <th>有給</th>
                        <th>振休</th>
                        <th>特別休</th>
                        <th>慶弔休</th>
                        <th>休出</th>
                        <th>本社出勤</th>
                    </tr>
                    </thead>
                    <tbody>
                    {chartData.map((s) => (
                        <tr key={s.employeeId}>
                            <td>{s.employeeName}</td>
                            <td>{s.totalWorkDays}</td>
                            <td>{s.totalWorkHours}</td>
                            <td>{s.lateCount}</td>
                            <td>{s.nightShiftHours}</td>
                            <td>{s.absences}</td>
                            <td>{s.substituteHolidays}</td>
                            <td>{s.paidLeave}</td>
                            <td>{s.dayOff}</td>
                            <td>{s.specialLeave}</td>
                            <td>{s.condolenceLeave}</td>
                            <td>{s.holidayWork}</td>
                            <td>{s.headOfficeAttendance}</td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default AdminWorkScheduleDashboard;
